Chapter 1,  Chapter 5, and Chapter 7 don't have any code files.

Make sure you set the environment variables properly as mentioned in Chapter 1.

Keep JIRA_INSTALL and JIRA_HOME directories separate which makes the maintenance and future upgrade work easier.

For Chapter 6 : All 3 email template files (issuerejected-html.vm, issuerejected-text.vm, issuerejected-subject.vm) should all be named issuerejected.vm, and be placed into their own folders.